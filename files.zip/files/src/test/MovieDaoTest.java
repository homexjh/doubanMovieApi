package test;

import java.util.ArrayList;
import java.util.List;

import dao.MovieDao;
import dao.MovieDaoImpl;
import vo.Movie;

public class MovieDaoTest {
	public static void main(String[] args) {
		MovieDao dao = new MovieDaoImpl();
		List<Movie> list = new ArrayList<Movie>();
		list = dao.listGetTopTen(5);
		System.out.println(list.toString());
	}
}
