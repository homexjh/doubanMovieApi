package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dao.MovieDao;
import dao.MovieDaoImpl;
import vo.Movie;

/**
 * Servlet implementation class MovieGetTen
 */
@WebServlet("/MovieGetTen")
public class MovieGetTen extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public MovieGetTen() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "GET,POST");
		int num = Integer.parseInt(request.getParameter("num"));
		response.setCharacterEncoding("UTF-8");	
		response.setContentType("text/html;charset=UTF-8");
		String s = "";
		MovieDao dao = new MovieDaoImpl();
		List<Movie> list = dao.listGetTopTen(num);
		Gson gson = new Gson();
		s = gson.toJson(list);
		PrintWriter out = response.getWriter();
		if(s.length() > 0) {
			out.print(s);
		}else {
			out.print("[]");
		}
		out.flush();
		out.close();
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
