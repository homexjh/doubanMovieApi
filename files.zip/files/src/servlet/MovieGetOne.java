package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dao.MovieDao;
import dao.MovieDaoImpl;
import vo.Movie;


/**
 * Servlet implementation class MovieGetOne
 */
@WebServlet("/MovieGetOne")
public class MovieGetOne extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public MovieGetOne() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "GET,POST");
		int id = Integer.parseInt(request.getParameter("id"));
		response.setContentType("text/json");
		response.setCharacterEncoding("utf-8");
		MovieDao dao = new MovieDaoImpl();
		String s = " ";
		Movie movie = dao.get(id);
		Gson gson = new Gson();
		s = gson.toJson(movie);
		PrintWriter out = response.getWriter();
		//out.print(id);
//		if(movie != null) {
//			out.print("{\"rank\":" + movie.getRank() + ",");
//			out.print("{\"title\":" + movie.getTitle() + ",");
//			out.print("{\"poster\":" + movie.getPoster() + ",");
//			out.print("{\"actor\":" + movie.getActor() + ",");
//			out.print("{\"country\":" + movie.getCountry() + ",");
//			out.print("{\"type\":" + movie.getType() + ",");
//			out.print("{\"grade\":" + movie.getGrade() + ",");
//			out.print("{\"comment\":" + movie.getComment() + ",");
//			out.print("{\"year\":" + movie.getYear() + ",");
//		}else {
//			out.print("{}");
//		}
		out.print(s);
		out.flush();
		out.close();
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
