package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dao.MovieDao;
import dao.MovieDaoImpl;
import vo.Movie;

/**
 * Servlet implementation class MovieGetAllType
 */
@WebServlet("/MovieGetAllType")
public class MovieGetAllType extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public MovieGetAllType() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "GET,POST");
		response.setCharacterEncoding("UTF-8");	
		response.setContentType("text/html;charset=UTF-8");
		String s = "";
		MovieDao dao = new MovieDaoImpl();
		List<Movie> list = dao.listAllType();
		Gson gson = new Gson();
		s = gson.toJson(list);
		PrintWriter out = response.getWriter();
		out.print(s);
		out.flush();
		out.close();
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
