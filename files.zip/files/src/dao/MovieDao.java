package dao;

import java.util.List;

import vo.Movie;

public interface MovieDao {
	List<Movie> listByMovie();
	Movie get(int id);
	List<Movie> listByType(String type);
	List<Movie> listAllType();
	List<Movie> listByYear(String year);
	List<Movie> listByCountry(String country);
	Movie getByTitle(String title);
	List<Movie> listGetTopTen(int num);
}
