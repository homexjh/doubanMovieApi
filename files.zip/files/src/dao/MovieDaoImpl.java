package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBUtil;
import vo.Movie;

public class MovieDaoImpl implements MovieDao {

	//��ȡ���е�Ӱ�б�
	@Override
	public List<Movie> listByMovie() {
		// TODO Auto-generated method stub
		List<Movie> list = new ArrayList<Movie>();
		DBUtil db = new DBUtil();
		Connection conn = db.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from Movie";
		try {
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setRank(rs.getInt("rank"));
				movie.setTitle(rs.getString("title"));
				movie.setPoster(rs.getString("poster"));
				movie.setActor(rs.getString("actor"));
				movie.setCountry(rs.getString("country"));
				movie.setType(rs.getString("type"));
				movie.setGrade(rs.getFloat("grade"));
				movie.setComment(rs.getString("comment"));
				movie.setYear(rs.getString("year"));
				list.add(movie);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			db.closeAll(rs, pst, conn);
		}
		return list;
	}

	//ͨ��id��ȡ��Ӧ�ĵ�Ӱ��Ϣ
	@Override
	public Movie get(int id) {
		// TODO Auto-generated method stub
		
		Movie movie = null;
		Connection conn = new DBUtil().getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from Movie where rank = ?";
		System.out.println("get");
		try {
			pst = conn.prepareStatement(sql);
			pst.setInt(1, id);
			
			rs = pst.executeQuery();
			while(rs.next()) {
				movie = new Movie();
				movie.setRank(id);
				movie.setTitle(rs.getString("title"));
				movie.setPoster(rs.getString("poster"));
				movie.setActor(rs.getString("actor"));
				movie.setCountry(rs.getString("country"));
				movie.setType(rs.getString("type"));
				movie.setGrade(rs.getFloat("grade"));
				movie.setComment(rs.getString("comment"));
				movie.setYear(rs.getString("year"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			new DBUtil().closeAll(rs, pst, conn);
		}
		return movie;
	}

	@Override
	public List<Movie> listByType(String type) {
		List<Movie> list = new ArrayList<Movie>();
		DBUtil db = new DBUtil();
		Connection conn = db.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from Movie where type = ?";
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, type);
			rs = pst.executeQuery();
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setRank(rs.getInt("rank"));
				movie.setTitle(rs.getString("title"));
				movie.setPoster(rs.getString("poster"));
				movie.setActor(rs.getString("actor"));
				movie.setCountry(rs.getString("country"));
				movie.setType(rs.getString("type"));
				movie.setGrade(rs.getFloat("grade"));
				movie.setComment(rs.getString("comment"));
				movie.setYear(rs.getString("year"));
				list.add(movie);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			db.closeAll(rs, pst, conn);
		}
		
		return list;
	}

	@Override
	public List<Movie> listAllType() {
		List<Movie> list = new ArrayList<Movie>();
		DBUtil db = new DBUtil();
		Connection conn = db.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select rank,title ,type,grade from Movie";
		try {
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while (rs.next()) {
				Movie movie = new Movie();			
				movie.setRank(rs.getInt("rank"));
				movie.setTitle(rs.getString("title"));
				movie.setType(rs.getString("type"));
				movie.setGrade(rs.getFloat("grade"));
				list.add(movie);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			db.closeAll(rs, pst, conn);
		}
		return list;
	}

	@Override
	public List<Movie> listByYear(String year) {
		List<Movie> list = new ArrayList<Movie>();
		DBUtil db = new DBUtil();
		Movie movie = new Movie();
		Connection conn = db.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from Movie where year = ? ";
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, year);
			rs = pst.executeQuery();
			while(rs.next()) {
				movie = new Movie();
				movie.setYear(year);
				movie.setRank(rs.getInt("rank"));
				movie.setTitle(rs.getString("title"));
				movie.setPoster(rs.getString("poster"));
				movie.setActor(rs.getString("actor"));
				movie.setCountry(rs.getString("country"));
				movie.setType(rs.getString("type"));
				movie.setGrade(rs.getFloat("grade"));
				movie.setComment(rs.getString("comment"));		
				list.add(movie);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	//��ȡĳһ���һ��ߵ����ĵ�Ӱ���б�
	@Override
	public List<Movie> listByCountry(String country) {
		// TODO Auto-generated method stub
		List<Movie> list = new ArrayList<Movie>();
		Movie movie = null;
		DBUtil db = new DBUtil();
		Connection conn = db.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		//String sql = "select top 10 * from Movie where country = ? and rank not in(select top "+n+" rank from Movie)";
		String sql = "select * from Movie where country = ?";
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, country);
			rs = pst.executeQuery();
			while(rs.next()) {
				movie = new Movie();
				movie.setCountry(country);
				movie.setRank(rs.getInt("rank"));
				movie.setTitle(rs.getString("title"));
				movie.setPoster(rs.getString("poster"));
				movie.setActor(rs.getString("actor"));
				movie.setType(rs.getString("type"));
				movie.setGrade(rs.getFloat("grade"));
				movie.setComment(rs.getString("comment"));	
				movie.setYear(rs.getString("year"));
				list.add(movie);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			db.closeAll(rs, pst, conn);
		}
		
		return list;
	}

	//���ݵ�Ӱ���ƻ�ȡ��Ӱ��Ϣ
	@Override
	public Movie getByTitle(String title) {
		Movie movie = null;
		DBUtil db = new DBUtil();
		Connection conn = db.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "  select * from Movie where title = ?;";
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, title);
			rs= pst.executeQuery();
			while(rs.next()) {
				movie = new Movie();
				movie.setTitle(title);
				movie.setRank(rs.getInt("rank"));
				movie.setPoster(rs.getString("poster"));
				movie.setActor(rs.getString("actor"));
				movie.setCountry(rs.getString("country"));
				movie.setType(rs.getString("type"));
				movie.setGrade(rs.getFloat("grade"));
				movie.setComment(rs.getString("comment"));
				movie.setYear(rs.getString("year"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return movie;
	}

	//��ҳ��ѯ��ÿ������ǰ���ȡ�Ĳ���ȡǰ10��
	@Override
	public List<Movie> listGetTopTen(int num) {
		int n = num * 10;
		List<Movie> list = new ArrayList<Movie>();
		DBUtil db = new DBUtil();
		Connection conn = db.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select top 10 * from Movie where rank not in(select top "+n+" rank from Movie)";
		try {
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while(rs.next()) {
				Movie movie = new Movie();
				movie.setRank(rs.getInt("rank"));
				movie.setTitle(rs.getString("title"));
				movie.setPoster(rs.getString("poster"));
				movie.setActor(rs.getString("actor"));
				movie.setCountry(rs.getString("country"));
				movie.setType(rs.getString("type"));
				movie.setGrade(rs.getFloat("grade"));
				movie.setComment(rs.getString("comment"));
				movie.setYear(rs.getString("year"));
				list.add(movie);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			db.closeAll(rs, pst, conn);
		}
		
		return list;
	}
	


}
