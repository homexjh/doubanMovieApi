package cn.hui;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import util.DBUtil;


public class Main {
	public static void main(String[] args) throws IOException {
		for (int i = 0; i < 10; i++) {
            int page = i * 25;
            Document document = (Document) Jsoup.connect("https://movie.douban.com/top250?start="+ page).userAgent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31").get();
            Elements items = document.getElementsByClass("item");
            for (Element item : items) {
                int num = Integer.parseInt(item.getElementsByTag("em").get(0).text());
                String title = item.getElementsByClass("hd").get(0).getElementsByTag("span").get(0).text();
                Elements el = item.getElementsByTag("a").get(0).getElementsByTag("img");
                String url = el.attr("src");
                String bd = item.getElementsByClass("bd").get(0).getElementsByTag("p").get(0).html();
                String actor = bd.split("<br />")[0].replaceAll("&nbsp;", "");
                String info = bd.split("<br />")[1].replaceAll("&nbsp;", " ");
                String[] infos = info.split("/");
                String year = infos[0].trim();
                String country = infos[1].trim();
                String type = infos[2].trim();
                float ratingNum = Float.parseFloat(item.getElementsByClass("rating_num").get(0).text());
                String quote = "";
                if (item.getElementsByClass("quote").size() > 0) {
                    quote = item.getElementsByClass("quote").get(0).text();
                }
               // String quote = item.getElementsByClass("quote").get(0).text();

                System.out.println("��Ӱ����: " + num);
                System.out.println("��Ӱ����: " + title);
                System.out.println("��Ӱ����: " + url);
                System.out.println("��Ӱ��Ա: " + actor);
                System.out.println("��Ӱ���: " + year);
                System.out.println("����: " + country);
                System.out.println("��Ӱ����: " + type);
                System.out.println("��Ӱ����: " + ratingNum);
                System.out.println("��Ӱ����: " + quote);
                System.out.println("============================================");
                
                Boolean result = false;
                Connection conn = new DBUtil().getConnection();
                PreparedStatement pst = null;
                String sql = "insert into Movie(rank,title,poster,actor,country,type,grade,comment,year) values(?,?,?,?,?,?,?,?,?);";
                try {
					pst = conn.prepareStatement(sql);
					pst.setFloat(1, (int)num);
					pst.setString(2, title);
					pst.setString(3, url);
					pst.setString(4, actor);
					pst.setString(5,country );
					pst.setString(6,type);
					pst.setFloat(7, ratingNum);
					pst.setString(8, quote);
					pst.setString(9, year);
					int k = pst.executeUpdate();
					if( k > 0) {
						result = true;
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					new DBUtil().closeAll(null, pst, conn);
				}           	
            }
        }
	}
}
